package com.qianfeng.dao;

import com.qianfeng.entity.OrderDetail;

public interface IOrderDetailDao {

	void addOrderDetail(OrderDetail od);

}
