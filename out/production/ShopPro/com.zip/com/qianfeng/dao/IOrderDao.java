package com.qianfeng.dao;

import com.qianfeng.entity.Order;

public interface IOrderDao {

	void addOrder(Order order);

}
