package com.qianfeng.service;

import com.qianfeng.entity.Order;

public interface IOrderService {

	void addOrder(Order order);

}
