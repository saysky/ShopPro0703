package com.qianfeng.service;

import com.qianfeng.entity.OrderDetail;

public interface IOrderDetailService {

	void addOrderDetail(OrderDetail od);

}
